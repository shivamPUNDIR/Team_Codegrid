<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
<meta charset="utf-8" />
<title>Webinars and In-Person Orientations </title>
<meta name="description" content="Orientation to Legal Researcher concerning the use of Law Library Collections. " />
<meta name="dc.subject" content="Legal Information" />
<meta name="dc.subject" content="Research" />
<meta name="dc.subject" content="Orientation" />
<meta name="dc.subject" content="Embassy" />
<meta name="dc.subject" content="Congress" />
<meta name="dc.identifier" content="//www.loc.gov/law/opportunities/seminar-orient.php" />
<meta rel="canonical" href="//www.loc.gov/law/opportunities/seminar-orient.php" />
<meta name="dc.type" content="web page" />
<meta name="dc.rights" content="Text is U.S. Government Work" />
<link rel="dc.rights" title="Rights Restriction" href="//www.loc.gov/text-us-government-work" />
<meta name="dc.language" content="eng" />
<link media="screen" rel="stylesheet" href="/law/css/styles.css" />
<link media="print" rel="stylesheet" href="/css/loc_print_v2.css" />
<!--[if lte IE 7]><link media="screen" rel="stylesheet" href="/css/loc_lte_ie6.css" /><![endif]-->
<!-- Toolbar -->
<script src="//cdn.loc.gov/sites/law-library-of-congress.js"></script>
<script src="//cdn.loc.gov/js/lib/modernizr-1.5.min.js"></script>


</head>
<body>
<a id="skip" href="#skip_menu">skip navigation</a>
<div id="container">
	<div id="branding">
  <h2>Library of Congress</h2>
  <h3>Law Library of Congress</h3>
</div>
<!-- end id:branding -->
	<div id="h-wrapper" class="fix-float">
  <div id="header" class="fix-float">
    <div class="logo">
      <a href="//www.loc.gov" accesskey="1"><img src="//cdn.loc.gov/images/img-head/logo-loc.png" width="141" height="32" alt="Library of Congress" /></a>
    </div>
    <div class="nav">
        <ul>
          <li><a class="btn-loc" href="//www.loc.gov/rr/askalib/" accesskey="2">Ask a Librarian</a></li>
          <li><a class="btn-loc" href="//www.loc.gov/library/libarch-digital.html" accesskey="3">Digital Collections</a></li>
          <li><a class="btn-loc" href="http://catalog.loc.gov/" accesskey="4">Library Catalogs</a></li>
        </ul>
    </div>
    <div class="search">
      <form action="//www.loc.gov/search" method="get">
        <label class="search_label" for="search">Search</label>
        <div class="search_wrap">
        <input type='hidden' name='new' value='true'/>
        <input id="search" type="search" name="q" maxlength="200" accesskey="/" title="Search the Library of Congress website" placeholder="Search Loc.gov" class="locsuggest" /><button class="button" id="search_button" type="submit">GO</button>
        </div>
      </form>
    </div>
  </div>
  <script src="//cdn.loc.gov/suggest/library-of-congress.js" type="text/javascript"></script>
</div>
	<div id="crumb_nav"><a href="//www.loc.gov">The Library of Congress</a> <span>&gt;</span> <a href="/law/">Law Library</a> <span>&gt;</span> <a href="/law/opportunities/">Educational &amp; Research Opportunities</a> &gt; Webinars and In-Person Orientations</div>
	<div id="content">
		
<!-- new left nav-->
<link href="../css/law.css" rel="stylesheet" type="text/css">


<div id="left_nav">
  <div class="box leftnavtitle"><a href="/law/"><img src="/law/images/left-img-head.gif" alt="Law Library of Congress" width="219" height="50" /></a></div>
  <div class="box leftnavimg">Law Library of Congress Logo</div>
  <div class="box">
    <form action="//www.loc.gov/search/" accept-charset="utf-8" id="site_search" name="seek1" method="get">
      <input type='hidden' name='in' value='PartOf:law library of congress'/>
      <!--<input type="hidden" name="qp" value="url:http://www.loc.gov/law" />-->
      <input id="searchtext" name="q" type="text" placeholder="Search this site" title="Search this site" onfocus="this.value=''" />
      <input class="button" type="submit" value="GO" />
    </form>
  </div>
  <div class="box">
    <ul class="arrow_o bold">
      <li><a href="/law/">Law Library Home</a></li>
      <li><a href="/law/about/">About the Law Library</a></li>
      <li><a href="/law/help/">Research &amp; Reports</a></li>
      <li><a href="/law/find/">Find Legal Resources</a></li>
      <li><a href="/law/opportunities/">Educational &amp; Research Opportunities</a></li>
      <li><a href="/law/visit/">Visiting the Law Library</a></li>
      <li><a href="/law/news/">News &amp; Events</a></li>
      <li><a href="/law/contact/">Contact</a></li>
      <li><a href="/law/about/jobs.php">Temporary Job Opportunities</a></li>
    </ul>
  </div>
  <div class="box blog">
    <h2><a href="http://blogs.loc.gov/law/">In Custodia Legis</a></h2>
    <p>Official blog from the Law Library of Congress</p>
  </div>
  <div class="box">
    <h2>Find the Law Library on:</h2>
    <ul class="social">
      <li class="facebook"><a class="external" href="http://www.facebook.com/lawlibraryofcongress" target="_blank">Facebook<span> (external link)</span></a></li>
      <li class="twitter"><a class="external" href="http://twitter.com/LawLibCongress" target="_blank">Twitter (Law Library)<span> (external link)</span></a></li>
      <li class="twitter"><a class="external" href="http://www.twitter.com/congressdotgov" target="_blank">Twitter (Congress.gov)<span>(external link)</span></a></li>
      <li class="youtube"><a class="external" href="http://www.youtube.com/playlist?list=PL96401BE3402149B9" target="_blank">YouTube<span> (external link)</span></a></li>
      <li class="itunes"><a class="external" href="https://itunes.apple.com/us/itunes-u/law-and-the-library/id386017780" target="_blank">iTunes<span> (external link)</span></a></li>
    </ul>
  </div>
</div>		<div id="main_body" role="main"> 
			<!-- Toolbar -->
			<div class="locshare-this" id='instance_access1001'></div>
			<div class="clear-share"> 
				<!-- --> 
			</div>
			<div id="page_head"><span style="width: 100%;"><a id="skip_menu"></a></span>
				<h1>Webinars and In-Person Orientations</h1>
			</div>
			<div class="box_img"><img src="/law/images/header_opportunities.jpg" alt="Educational Program" /></div>
			<div id="main_nav"><a href="/law/opportunities/">Educational &amp; Research Opportunities</a> | <a href="scholar.php">Scholarly Programs</a>&nbsp;|&nbsp;<a href="attorneys.php">Opportunities for Attorneys</a> | Webinars and In-Person Orientations</div>

			
			<h2>Congress.gov</h2>

<p>This orientation is designed to give a basic overview of Congress.gov. While the focus of the session will be searching legislation and the Congressional member information attached to the legislation, the new features of Congress.gov will be highlighted. To register, follow the link(s) below. 
 Congress.gov webinar sessions are on Thursdays from 2 to 3pm.
 </p>  

<p>The following Congress.gov webinar sessions are planned for 2020 and are available for registration:</p>
<ul>
  <li><a href="https://congressdotgov-webinar-january-30-2020.eventbrite.com"> January 30, 2020</a></li>
  <li><a href="https://congressdotgov-webinar-march-26-2020.eventbrite.com">March 26, 2020</a></li>
  <li><a href="https://congressdotgov-webinar-may-28-2020.eventbrite.com">May 28, 2020</a></li>
  <li><a href="https://congressdotgov-webinar-july-30-2020.eventbrite.com">July 30, 2020</a></li>
  <li><a href="https://congressdotgov-webinar-september-17-2020.eventbrite.com">September 17, 2020</a></li>
</ul>

		  <h2>Legal Research</h2>
		  <p>The Law Library of Congress currently offers two types of  in-person classes: <em>Orientation to Legal Research Series</em> and <em>Orientation  to Law Library Collections</em>. </p>
			<p>			  The <em>Orientation to Legal Research Series</em> of classes  are designed to give a basic introduction to legal sources and research  techniques.&nbsp;These orientations, taught by legal reference librarians, are  typically offered once a month on a rotating basis, from 10:00 am to 11:00 am.  There are three classes in this series, including:</p>
            <ul>
              <li><span dir="LTR"> </span><em>U.S. Case Law</em> – This  entry in the series provides an overview of U.S. case law research, including  information about the U.S. federal court system, the publication of court  opinions, methods for researching case law, and information about locating  records and briefs. To register for the class, please click <a href="https://olr-series-us-case-law-2020.eventbrite.com/">here</a> or call  (202) 707-5080. </li>
              <li><span dir="LTR"> </span><em>U.S. Federal Statutes</em> – This entry in the series provides an overview of U.S. statutory and  legislative research, including information about how to find and use the <em>U.S.  Code</em>, the <em>U.S. Statutes at Large</em>, and U.S. federal bills and  resolutions. To register for the class, please click <a href="https://olr-series-us-statutes-2020.eventbrite.com/">here</a> or call  (202) 707-5080.</li>
              <li><span dir="LTR"> </span><em>Tracing Federal  Regulations</em> – This entry in the series provides an overview of U.S. federal  regulations, including information about the notice and comment rulemaking  process, the publication and citation of regulations, and the tracing of  regulations from the <em>Code of Federal Regulations</em>, to the proposed rule  in the <em>Federal Register</em>, to the regulation&rsquo;s docket. To register for the  class, please click <a href="https://olr-series-tracing-federal-regulations-2020.eventbrite.com/">here</a> or call (202) 707-5080.            </li>
            </ul>
            <p>The <em>Orientation to Law Library Collections</em> is  designed for patrons who are familiar with legal research, and would instead  prefer an introduction to the collections and services specific to the Law  Library of Congress. These one-hour orientations are taught once a month by  legal reference librarians from the Law Library of Congress. To register,  please click <a href="https://orientation-to-law-library-collections-2020.eventbrite.com/">here</a> or call (202) 707-5080.</p>
          <p>The <em>Orientation to Law Library Collections</em> class is  also offered on two Saturdays a year. To find more information about these  classes and to sign up, please visit the <a href="https://www.loc.gov/rr/main/satorient/">Saturday Classes for Researchers</a> page.</p>
          <p>Prior to attending any in-person class, patrons will need to  obtain a <a href="https://www.loc.gov/rr/readerregistration.html">Library of  Congress Registration Card</a>.</p>
          <h2>Orientation to Legal Research Webinar Series</h2>
          <p>The <em>Orientation to Legal Research Series</em> of webinars reflect the content in the in-person series of classes, and are designed to give a basic introduction to legal sources and research techniques. These orientations, taught by legal reference librarians, are typically offered once a month on a rotating basis, from 11:00 am to 12:00 pm. To register for the next class, please click the link below or call (202) 707-5080.</p>
          <p><a href="https://olr-webinar-series-us-case-law-2-2020.eventbrite.com/">U.S. Case Law</a><br>
          February 20, 2020</p>
          <blockquote>
            <p>This entry in the series provides an overview of U.S. case law research, including information about the U.S. federal court system, the publication of court opinions, methods for researching case law, and information about locating records and briefs.<br>
              <br>
            </p>
          </blockquote>
          <h2>Comparative Law Webinar Series</h2>
          <p>The<EM> Comparative Law Webinar Series</EM><EM> </EM>of classes is designed to shed light on some of the comparative law issues researched by the foreign law experts at the Law Library of Congress. <br>
          </p>
             <p><a href="https://foreign-comparative-law-israeli-election-2-2020.eventbrite.com/">What You Need to Know About the Upcoming Israeli National Election</a><br>
          February 27, 2020 at 10am</p>
          <blockquote>
            <p>This entry in the series will address general principles of the Israeli government system, rules governing national election, the method of distribution of Knesset seats, government formation procedures, prime-ministerial qualifications and term limits, and the legal implications of a Knesset Member’s indictment on presidential discretion in assignment of government formation. Topics may be adjusted as warranted to address ongoing developments. To register, please click <a href="https://foreign-comparative-law-israeli-election-2-2020.eventbrite.com/">here</a> or call (202)  707-5080.<br>
            </p>
            
            
          </blockquote>
			<!--<p>Please complete the <a href="/law/opportunities/seminar-form.php">Seminar Form</a> to register for <em>Orientation</em><em> Legal Research and the Use of Law Library Collections</em>.    Please provide your name, contact information, and the class you wish to attend   from the drop down menu.</p>-->
			<a name="embassy"></a>
		  <h2>Legal Research for Embassy Personnel</h2>
			<p><em>Legal Research Orientation for Embassy Personnel</em> is designed to  include approaches to legal research regarding United States federal law.  Attendees will be shown how to access statutes, treaties, administrative  regulations, and court cases, using a host of print and electronic sources and  databases. These orientations, taught by reference librarians, are offered upon  Embassy request. </p>
		    <p>For further information, please email <a href="/cdn-cgi/l/email-protection#5b373a2c342e2f293e3a38331b373438753c342d"><span class="__cf_email__" data-cfemail="97fbf6e0f8e2e3e5f2f6f4ffd7fbf8f4b9f0f8e1">[email&#160;protected]</span></a>. </p>
<!--<h2>THOMAS</h2>
			<p>The THOMAS Orientation is designed to give a basic overview of the THOMAS website through lecture and hands-on exercises. Searching legislation, public laws or bills, and the congressional documents that pertain to the legislative process is the primary focus of the session. Specialized areas of the website, like the legislative process and status of appropriations, will be reviewed.   The orientations taught by reference librarians are offered bimonthly.  To register, sign up in person in the Law Library Reading Room (LM201), call (202) 707-9801, or complete the Seminar Form.  Prior to attending a class, you need to obtain a <a href="//www.loc.gov/rr/readerregistration.html">Library of Congress Registration Card</a>.
			
			<p>Please complete the <a href="/law/opportunities/thomas-form.php">Seminar Form</a> to register for one of the THOMAS Orientations.  Please provide your name, contact information, and the class you wish to attend from the drop down menu.</p>-->
			
		 

		  <p class="last_updated">Last Updated: 01/29/2020</p>
		</div>
		<!-- end id:main_body --> 
	</div>
	<!-- end id:content -->
		<!-- begin: global footer -->
  <div id="f-wrapper" class="fix-float">
  <div id="footer" class="fix-float">
      <div class="cols heading">
        <h2>Connect with the Library</h2>
        <p><a class="ar-more foot" href="//www.loc.gov/homepage/connect.html">All ways to connect</a></p>
      </div>
      <div class="cols">
        <h3>Find Us On</h3>
        <a href="http://www.pinterest.com/LibraryCongress/"><img src="//cdn.loc.gov/images/img-foot/pinterest.gif" alt="Pinterest" width="16" height="16" /></a> &nbsp; <a href="http://www.facebook.com/libraryofcongress"><img src="//cdn.loc.gov/images/img-foot/facebook.gif" alt="Facebook" width="16" height="16" /></a> &nbsp; <a href="http://twitter.com/#!/librarycongress"><img src="//cdn.loc.gov/images/img-foot/twitter.gif" alt="Twitter" width="16" height="16" /></a> &nbsp; <a href="http://www.youtube.com/libraryofcongress"><img src="//cdn.loc.gov/images/img-foot/youtube.gif" alt="YouTube" width="16" height="16" /></a> &nbsp; <a href="http://www.flickr.com/photos/library_of_congress/"><img src="//cdn.loc.gov/images/img-foot/flickr.gif" alt="Flickr" width="16" height="16" /></a>
      </div>
      <div class="cols">
        <h3>Subscribe &amp; Comment</h3>
        <ul class="plain">
          <li><a href="//www.loc.gov/rss/">RSS &amp; E-Mail</a></li>
          <li><a href="http://blogs.loc.gov/">Blogs</a></li>
        </ul>
      </div>
      <div class="cols">
        <h3>Download &amp; Play</h3>
        <ul class="plain">
          <li><a href="//www.loc.gov/apps/">Apps</a></li>
          <li><a href="//www.loc.gov/podcasts/">Podcasts</a></li>
          <li><a href="//www.loc.gov/today/cyberlc/index.php">Webcasts</a></li>
          <li><a href="http://itunes.apple.com/us/institution/library-of-congress/id386017159" class="external foot mod">iTunesU<span> (external link)</span></a></li>
        </ul>
      </div>
      <div class="cols">
        <h3>Questions</h3>
        <ul class="plain">
          <li><a href="//www.loc.gov/rr/askalib/">Ask a Librarian</a></li>
          <li><a href="//www.loc.gov/help/contact-general.html" accesskey="8">Contact Us</a></li>
        </ul>
      </div>
      <div class="clear"><!-- --></div>
      <p class="links">
      <a href="//www.loc.gov/about/">About</a> |
      <a href="//www.loc.gov/pressroom/login">Press</a> |
      <a href="//www.loc.gov/hr/employment/index.php">Jobs</a> |
      <a href="//www.loc.gov/philanthropy/index.php">Donate</a>
      <br />
      <a href="//www.loc.gov/about/oig/">Inspector General</a> |
      <a href="//www.loc.gov/homepage/legal.html" accesskey="9">Legal</a> |
      <a href="//www.loc.gov/access/" accesskey="0">Accessibility</a> |
      <a href="//www.loc.gov/global/disclaim.html">External Link Disclaimer</a> |
      <a href="http://www.usa.gov/">USA.gov</a>
      </p>
      <span class="speech"><a href="//www.loc.gov/access/web.html">Speech Enabled</a></span>
  </div><!-- end id:footer -->
  </div><!-- end id:f-wrapper -->
	<!-- end: global footer -->	<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src='https://cdn.loc.gov/js/global/metrics/sc/s_code.js?35836.31053'></script></div>
<!-- end id:container -->
</body>
</html>