<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
<title>Support the Library (Library of Congress)</title>
<meta http-equiv="Content-Language" content="en-us" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="support, donation, give, giving, philanthropy, gift, development, development office, funding, library projects, initiatives, proposal, funds, money, contribution, contribute, james madison council, private sector" />
<meta name="description" content="Options and opportunities for supporting Library of Congress." />
<script type="text/javascript" src="swf/swfobject.js"></script>
<link rel="stylesheet" media="print" type="text/css" href="/css/loc_print2col_ss.css" />
<style type="text/css">
@import url(../css/loc_standard_ss.css);
@import url(css/philanthropy_home_ss.css);
@import url(css/philanthropy_sub.css);
</style>
<script src="//assets.adobedtm.com/dac62e20b491e735c6b56e64c39134d8ee93f9cf/satelliteLib-6b47f831c184878d7338d4683ecf773a17973bb9.js"></script>
</head>
<body>
<a id="skip" href="#skip_menu">skip navigation</a>
<div id="container">
  	<div id="topnav">
    <ul id="menu">
      <li id="logo_lc"><a title="The Library of Congress" href="//www.loc.gov" accesskey="1"></a></li>
      <li id="global_nav"><a href="//www.loc.gov/rr/askalib/" accesskey="2"><img src="//www.loc.gov/images/ask_librarian.gif" alt="Ask a Librarian" width="101" height="40" /></a><a href="//www.loc.gov/library/libarch-digital.html" accesskey="3"><img src="//www.loc.gov/images/digital_collections.gif" alt="Digital Collections" width="119" height="40" /></a><a href="http://catalog.loc.gov/" accesskey="4"><img src="//www.loc.gov/images/library_catalog.gif" alt="Library Catalogs" width="111" height="40" /></a></li>
      <li id="searchmenu">
        <form action="//www.loc.gov/search" method="get">
          &nbsp;<label for="search" class="lcsearch_label">Search</label>
          <input type='hidden' name='new' value='true'/>
          <input id="search" type="text" name="q" maxlength="250" accesskey="/" title="Search the Library of Congress website" class="locsuggest" />
          <input class="button" id="search_button" name="search_button" type="submit" value="GO" />
        </form>
      </li>
    </ul>
  </div><!-- end id:topnav -->
  <script src="//cdn.loc.gov/suggest/bootstrap-1.1.0.min.js" type="text/javascript"></script>  <div id="crumb_nav">
    <div id="crumb"><a href="//www.loc.gov/">The Library of Congress</a>&nbsp;>&nbsp;Support the Library </div>
  </div>
  <div id="content">
    <style type="text/css">
<!--
.modeselector {
	color: #990000;
	font-weight: bold;
	font-size: 18px;
}
-->
</style>

<div id="left_nav">
  <div id="left_nav_top"><a href="/philanthropy/"><img src="/philanthropy/images/lc_support.gif" alt="Support the Library" width="197" height="50" /></a></div>
  <div id="left_nav_mid">
        <ul id="navigate">
       <li>Support Home </li>
	            
	   <li><a href="/philanthropy/madison.php"><strong>James Madison Council</strong></a> </li>
	   <li><a href="/philanthropy/corporate.php"><strong>Corporate Giving</strong></a> </li>
	   <li><a href="/philanthropy/planned.php"><strong>Planned Giving</strong></a> </li>
	   <li><a href="/philanthropy/friends.php"><strong>Friends Groups</strong></a> </li>
	   <li><a href="/philanthropy/donate.php"><strong>Other Ways to Give</strong></a> </li>
    </ul>
    <h2>Donate Online Now</h2>
	<p>Charitable gifts support Library of Congress programs and help to bolster acquisitions, publications, events, access, exhibitions, special programs, internships and other activities. Please consider making a tax-deductible donation. </p>
	<p><img src="/images/arrow_o.gif" alt="" />&nbsp;<a href="/philanthropy/giving/step1.php">Donate online now</a></p>
	<h2>For More Information</h2>
   	<p><a href="about.php">Development Office</a><br />
       Library of Congress<br />
       101 Independence Ave., S.E.<br />
      Washington, DC 20540-1400</p>
    <p> <strong>Voice:</strong> (202) 707-2777<br />
        <strong>Fax:</strong> (202) 707-0312<br />
        <strong>E-mail:</strong>&nbsp;<a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="90f4f5e6fff6f3d0fcfff3bef7ffe6">[email&#160;protected]</a></p>
	  </div>
  <!-- closing left_nav div tag -->
</div>
    <div id="page_head"><span style="width: 100%;"><a name="skip_menu"></a></span>
      <h1 class="oneline">Support the Library </h1>
    </div>
    <div id="main_menu"> <img src="images/support_home.jpg" name="feature" width="529" height="132" border="0" id="feature" />
      <div id="main_body">
        <p>The Library of Congress, the nation's oldest federal cultural institution, is the world's preeminent reservoir of knowledge, providing unparalleled integrated resources to Congress and the American people. The Library seeks to further human understanding and wisdom by providing access to knowledge through its collections, which bring to bear the world's knowledge in almost all of the world's languages and America's private sector intellectual and cultural creativity in almost all formats. The Library needs your support to help build, preserve and make universally accessible its unparalleled resources. All donations to the Library are tax deductible. </p>
        <!-- < <p>This online donation program is made possible through the generous support of the <a href="leaders.php">Leaders Circle</a>.  &nbsp;Learn more about the <a href="about.php">Development Office</a>.</p>
          p><img src="/images/arrow_o.gif" alt="" /></p>-->
        
        <p>Please use the links below to support us today. </p>
        <form action="giving/step2.php" method="post" name='Step1' class="public" id="Step1">
          <input type="hidden" name="DonationFundType" value="" />
          <div class="features"> <img src="images/thumbs/where4.jpg" alt="James Madison Council Fund">
            <p><a href="#madison_council">James Madison Council Fund</a>&nbsp;&nbsp;&nbsp;&nbsp;<br />
              <img class="go" src="../../images/arrow_o.gif" alt="Go" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/James Madison Council Fund">Donate Now</a></p>
          </div>
          <div class="features"> <img src="images/thumbs/where3.jpg" alt="Where it is needed most"/>
            <p><a href="#needed_most">Where it is needed most</a>&nbsp;&nbsp;&nbsp;&nbsp;<br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9"/>&nbsp;<a href="/philanthropy/online-donation/fund/Where%20It's%20Needed%20Most">Donate Now</a></p>
          </div>
          <div class="features"> <img src="images/thumbs/acquire.jpg" alt="Acquire rare and unique items"/>
            <p><a href="#rare_items">Acquire rare and unique items</a>&nbsp;&nbsp;&nbsp;&nbsp;<br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Acquire rare and unique items">Donate Now</a></p>
          </div>
          <div class="features"> <img src="images/thumbs/preserve.jpg" alt="Preserve and protect collections for future generations"/>
            <p><a href="#preserve_for_future">Preserve and protect collections for future generations</a>&nbsp;<br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Preserve and protect collections for future generations">Donate Now</a></p>
          </div>
          <h3>Support Key Library Initiatives</h3>
          <ul>
            <li><a href="#american_folklife">American Folklife Center</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/American Folklife Center">Donate Now</a></li>
            <li><a href="#asian_division">Asian Division Gift Fund</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Asian Division Gift Fund">Donate Now</a></li>
            <li><a href="#ridgway">Elizabeth Ridgway Education Fund</a>&nbsp;&nbsp;<img class="go" src="../images/arrow_o.gif" alt="go" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Elizabeth Ridgway Education Fund">Donate Now</a>
            <li><a href="#exhibitions_educational">Exhibitions and Educational Programs</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Exhibitions and Educational Programs">Donate Now</a></li>
            <li><a href="#friends_law">Law Library of Congress</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Law Library of Congress">Donate Now</a></li>
            <li><a href="#literacy_reading">Literacy and Reading Programs</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Literacy and Reading Programs">Donate Now</a></li>
            <li><a href="#motion_picture">Motion Picture, Broadcasting, and Recorded Sound</a>&nbsp; <img class="go" src="../../images/arrow_o.gif" alt="Go" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Motion Picture, Broadcasting, and Recorded Sound">Donate Now</a></li>
            <li><a href="#book_festival">National Book Festival</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/National Book Festival">Donate Now</a></li>
            <li><a href="#blind_print_disabled">National Library Service for the Blind and Print Disabled</a> <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" /> <a href="https://www.loc.gov/philanthropy/online-donation/fund/National Library Service for the Blind and Print Disabled">Donate Now</a></li>
            <li><a href="#scholarly_programs">Scholarly Programs</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Scholarly Programs">Donate Now</a></li>
            <li><a href="#veterans_history">Veteran's History Project</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Veterans History Project">Donate Now</a></li>
            <li><a href="#wdl">World Digital Library</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/World Digital Library">Donate Now</a></li>
          </ul>
          <h3>Support Friends Groups</h3>
          <ul>
            <li><a href="#friends_music">Friends of Music</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Friends of Music">Donate Now</a></li>
            <li><a href="#friends_poetry">Friends of the Poetry and Literature Center</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Friends of the Poetry and Literature Center">Donate Now</a></li>
            <li><a href="#geography_maps">Geography and Maps - Philip Lee Phillips Society</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Geography and Maps - Philip Lee Phillips Society">Donate Now</a></li>
            <li><a href="#hispanic_division">Hispanic Division - Archer M. Huntington Society</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Hispanic Division - Archer M. Huntington Society">Donate Now</a></li>
            <li><a href="#rueben_friends_preservation">Reuben Foster Simms Friends of Preservation</a>&nbsp; <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Reuben Foster Simms Friends of Preservation">Donate Now</a></li>
          </ul>
          <p>&nbsp;<a href="/philanthropy/online-donation/fund/I would like to donate to a fund not listed">I would like to donate to a fund not listed.</a>&nbsp;<img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/I would like to donate to a fund not listed">Donate Now</a></p>
          <h2>Details about funds and programs you can support</h2>
          <div class="details"><a name="rare_items" id="rare_items"></a> <img src="images/thumbs/acquire1.jpg" alt="Acquire rare and unique items"/>
            <h3>Acquire rare and unique items</h3>
            <p style="padding-left:85px" >Assist in building the national collection, adding unique and highly sought after materials to the Library's holdings.&nbsp; <br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Acquire rare and unique items">Donate Now</a></p>
          </div>
          <div class="details"><a name="american_folklife" id="american_folklife"></a> <img src="images/thumbs/american.jpg" alt="American Folklife Center - Friends of the Folk Archives"/>
            <h3>American Folklife Center</h3>
            <p style="padding-left:85px">Support America's first national archive of traditional life, and one of the oldest and largest of such repositories in the world.&nbsp; <br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/American Folklife Center">Donate Now</a></p>
          </div>
          <div class="details"><a name="asian_division" id="asian_division"></a> <img src="images/thumbs/asian.jpg" alt="Asian Division Friends Society"/>
            <h3>Asian Division Gift Fund</h3>
            <p style="padding-left:85px">The Asian Division Gift Fund supports projects and activities such as exhibits, conferences, publications, lectures and special acquisitions and processing of Asian materials. These activities will both enhance the Asian Division and improve public awareness of and access to one of the Library’s most valuable collections.<br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Asian Division Gift Fund">Donate Now</a></p>
          </div>
          <div class="details"><a name="ridgway" id="ridgway"></a> <img style="padding: 1px;border: 1px solid #900;" src="images/thumbs/ridgway.jpg" alt="" />
            <h3>Elizabeth Ridgway Education Fund</h3>
            <p style="padding-left:85px">Support teacher training activities and programs that allow students to interact with the Library and its educational materials onsite, online, or in the classroom. Gifts are in memory of the Library’s friend and colleague Elizabeth Ridgway, Director, Educational Outreach.&nbsp; <br />
              <img class="go" src="../images/arrow_o.gif" alt="Go" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Elizabeth Ridgway Education Fund">Donate Now</a><br />
            </p>
          </div>
          <div class="details"><a name="exhibitions_educational" id="exhibitions_educational"></a> <img src="images/thumbs/exhibitions.jpg" alt="Exhibitions and Educational Programs"/>
            <h3>Exhibitions and Educational Programs</h3>
            <p style="padding-left:85px">Support innovative exhibitions, digital outreach, publications and a wide range of educational programming designed  to make the Library’s collections more accessible than ever!&nbsp; <br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Exhibitions and Educational Programs">Donate Now</a></p>
          </div>
          <div class="details"><a name="friends_music" id="friends_music"></a> <img src="images/thumbs/friends_of_music.jpg" alt="Friends of Music"/>
            <h3>Friends of Music</h3>
            <p style="padding-left:85px">Support the Library's internationally recognized concert series featuring legendary artists from around the world. Your contributions help make these concerts free to the public.&nbsp; <br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Friends of Music">Donate Now</a></p>
          </div>
          <div class="details"><a name="friends_poetry" id="friends_poetry"></a> <img src="images/thumbs/friends_of_poetry.jpg" alt="Friends of the Poetry and Literature Center" />
            <h3>Friends of the Poetry and Literature Center</h3>
            <p style="padding-left:85px">This new community of literature lovers will ensure the stability and growth of the Center's activities and its signature Poet Laureate Consultant in Poetry position.&nbsp; <br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Friends of the Poetry and Literature Center">Donate Now</a></p>
          </div>
          <div class="details"><a name="geography_maps" id="geography_maps"></a> <img src="images/thumbs/geography.jpg" alt="Geography and Maps - Philip Lee Phillips Society"/>
            <h3>Geography and Maps - Philip Lee Phillips Society</h3>
            <p style="padding-left:85px">Support the acquisition of rare maps and further the development, enhancement and promotion of the world's largest and most comprehensive cartographic collection.&nbsp;<br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Geography and Maps - Philip Lee Phillips Society">Donate Now</a></p>
          </div>
          <div class="details"><a name="hispanic_division" id="hispanic_division"></a> <img src="images/thumbs/hispanic20.jpg" alt="Hispanic Division - Archer M. Huntington Society"/>
            <h3>Hispanic Division - Archer M. Huntington Society</h3>
            <p style="padding-left:85px">Support Luso-Hispanic-related internet and publications  highlighting the educational, literary and other cultural programs of the Hispanic Division.&nbsp;<br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Hispanic Division - Archer M. Huntington Society">Donate Now</a></p>
          </div>
          <div class="details"><a name="madison_council" id="madison_council"></a> <img src="images/thumbs/madison.jpg" alt="James Madison Council Fund"/>
            <h3>James Madison Council Fund</h3>
            <p style="padding-left:85px">Donations to the James Madison Council Fund enable the Library to make its resources available to Congress and the American people and to sustain and preserve a universal collection of knowledge and creativity for future generations, including making hundreds of educational, cultural, and scholarly initiatives possible throughout the Library and the nation.&nbsp;<br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/James Madison Council Fund">Donate Now</a></p>
          </div>
          <div class="details"><a name="friends_law" id="friends_law"></a> <img src="images/thumbs/firends_of_the_law.jpg" alt="Law Library of Congress"/>
            <h3>Law Library of Congress</h3>
            <p style="padding-left:85px">Support  the Law Library - the world’s largest collection of law books and legal resources - by contributing to its collections and sponsoring programs that promote a better understanding of law.&nbsp; <br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Law Library of Congress">Donate Now</a><br />
            </p>
          </div>
          <div class="details"><a name="literacy_reading" id="literacy_reading"></a> <img src="images/thumbs/literacy.jpg" alt="Literacy and Reading Programs"/>
            <h3>Literacy and Reading Programs</h3>
            <p style="padding-left:85px">Support the world's largest library in its efforts to promote literacy and to stimulate interest in books, reading and libraries through  its Center for the Book.&nbsp;<br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Literacy and Reading Programs">Donate Now</a></p>
          </div>
          <div class="details"><a name="motion_picture" id="motion_picture"></a> <img style="padding: 1px;border: 1px solid #900;margin-right: 15px;" src="images/thumbs/mbrs.jpg" alt="Motion Picture, Broadcasting, and Recorded Sound"/>
            <h3>Motion Picture, Broadcasting, and Recorded Sound</h3>
            <p style="padding-left:85px">Support efforts to preserve and provide access to the world’s largest and most comprehensive collection of films, television programs, radio broadcasts, and sound recordings.&nbsp;<br />
              <img class="go" src="/images/arrow_o.gif" alt="Go" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Motion Picture, Broadcasting, and Recorded Sound">Donate Now</a></p>
          </div>
          <div class="details"><a name="book_festival" id="book_festival"></a> <img src="images/thumbs/nationalbook.jpg" alt="National Book Festival"/>
            <h3>National Book Festival</h3>
            <p style="padding-left:85px">Since 2001, the annual National Book Festival has been the premier celebration of the joy of reading and the creativity of America's authors, illustrators, and poets. Support this unique annual celebration of books and reading.&nbsp;<br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/National Book Festival">Donate Now</a><br />
            </p>
          </div>
          <div class="details"><a name="blind_print_disabled" id="blind_print_disabled"></a> <img src="images/thumbs/national.jpg" alt="National Library Service for the Blind and Print Disabled"/>
            <h3>National Library Service for the Blind and Print Disabled</h3>
            <p style="padding-left:85px">Help make recorded, large print or Braille books, magazines, music scores and specially designed playback equipment available at no charge to U.S. residents with visual or other physical limitations.&nbsp; <br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="https://www.loc.gov/philanthropy/online-donation/fund/National Library Service for the Blind and Print Disabled">Donate Now</a><br />
            </p>
          </div>
          <div class="details"><a name="preserve_for_future" id="preserve_for_future"></a> <img src="images/thumbs/preserve0.jpg" alt="Preserve and protect collections for future generations"/>
            <h3>Preserve and protect collections for future generations</h3>
            <p style="padding-left:85px">Support key programs and activities focused on the preservation of rare and unique archival materials and collections.&nbsp; <br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Preserve and protect collections for future generations">Donate Now</a></p>
          </div>
          <div class="details"><a name="rueben_friends_preservation" id="rueben_friends_preservation"></a> <img src="images/thumbs/reuben.jpg" alt="Reuben Foster Simms Friends of Preservation"/>
            <h3>Reuben Foster Simms Friends of Preservation</h3>
            <p style="padding-left:85px">Support programs and activities for the advancement of preservation of heritage collections at the Library of Congress and nationwide.<br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Reuben Foster Simms Friends of Preservation">Donate Now</a></p>
          </div>
          <div class="details"><a name="scholarly_programs" id="scholarly_programs"></a> <img src="images/thumbs/scholarly.jpg" alt="Scholarly Programs"/>
            <h3>Scholarly Programs</h3>
            <p style="padding-left:85px">Support lectures, conferences, symposia with visiting scholars, professional visitor exchanges, internships, exhibits and publications.&nbsp; <br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" />&nbsp;<a href="/philanthropy/online-donation/fund/Scholarly Programs">Donate Now</a></p>
          </div>
          <div class="details"><a name="veterans_history" id="veterans_history"></a> <img src="images/thumbs/veterans1.jpg" alt="Veterans History Project"/>
            <h3>Veterans History Project</h3>
            <p style="padding-left:85px;">Every veteran has his or her own war, and each is custodian of unique stories and memories. Support the Library’s  efforts to preserve their legacy with the gathering, processing, preservation, and access to riveting oral histories and personal documents collected from veterans from all wars.&nbsp;&nbsp;<br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" /><a href="/philanthropy/online-donation/fund/Veterans History Project">Donate Now</a></p>
          </div>
          <div class="details"><a name="wdl" id="wdl"></a> <img src="images/thumbs/wdl.gif" alt="World Digital Library"/>
            <h3>World Digital Library</h3>
            <p style="padding-left:85px;">The World Digital Library is a collaborative project, led by the Library of Congress, to digitize and provide access to primary cultural resources from around the world, including the major Asian, Islamic and non-Western cultures.<br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" /><a href="/philanthropy/online-donation/fund/World Digital Library">Donate Now</a></p>
          </div>
          <div class="details"><a name="needed_most" id="needed_most"></a> <img src="images/thumbs/where2.jpg" alt="Where it is needed most"/>
            <h3>Where it is needed most.</h3>
            <p style="padding-left:85px;">Help fund the most critical of initiatives that bring the Library's vast resources to people around the country and throughout the world.<br />
              <img class="go" src="/images/arrow_o.gif" alt="" width="9" height="9" /><a href="/philanthropy/online-donation/fund/Where%20It's%20Needed%20Most">Donate Now</a></p>
          </div>
          <p>The Library of Congress online giving program is made possible through the generous support of the <a href="//www.loc.gov/philanthropy/leaders.php">Leaders Circle</a>. &nbsp;&nbsp;&nbsp;<br />
            <br />
            <img src="/images/arrow_up.gif" alt="" name="up" id="up" border="0" height="9" width="9" />&nbsp;<a href="#skip_menu">Back to Top</a><br />
          </p>
        </form>
      </div>
    </div>
  </div>
  <div id="footer">
<h3>Stay Connected with the Library <a href="//www.loc.gov/homepage/connect.html">All ways to connect</a> <a class="nounderline" href="//www.loc.gov/homepage/connect.html">&raquo;</a></h3>
<div id="find_us">
<h4>Find us on</h4>
 <a href="http://www.pinterest.com/LibraryCongress/"><img src="//cdn.loc.gov/images/img-foot/pinterest.gif" alt="Pinterest" width="16" height="16" /></a><a href="http://www.facebook.com/libraryofcongress"><img src="//www.loc.gov/include/images/facebook.gif" alt="Facebook" width="16" height="16" /></a><a href="http://twitter.com/librarycongress"><img src="//www.loc.gov/include/images/twitter.gif" alt="Twitter" width="16" height="16" /></a><a href="http://www.youtube.com/libraryofcongress"><img src="//www.loc.gov/include/images/youtube.gif" alt="YouTube" width="16" height="16" /></a><a href="http://www.flickr.com/photos/library_of_congress/"><img src="//www.loc.gov/include/images/flickr.gif" alt="Flickr" width="16" height="16" /></a></div>
<div id="subscribe">
<h4>Subscribe &amp; Comment</h4>
<ul>
<li id="rssandemail"><a href="//www.loc.gov/rss/">RSS &amp; E-Mail</a></li>
<li id="blogs"><a href="http://blogs.loc.gov/">Blogs</a></li>
</ul>
</div>
<div id="download">
<h4>Download &amp; Play</h4>
<ul>
<li id="podcasts"><a href="//www.loc.gov/podcasts/">Podcasts</a></li>
<li id="webcasts"><a href="//www.loc.gov/webcasts/">Webcasts</a></li>
<li id="itunes"><a class="external" href="https://itunes.apple.com/us/institution/library-of-congress/id386017159"><span class="underline">iTunes U</span><span class="external2" title="external link" style="padding-right:8px;">&nbsp;</span></a></li>
</ul>
</div>

<div id="site_links" style="font-size:.95em !important;">
<a href="//www.loc.gov/about/">About</a> | 
<a href="https://www.loc.gov/news">Press</a> | 
<a href="//www.loc.gov/hr/employment/index.php">Jobs</a> | 
<a href="https://www.loc.gov/philanthropy/online-donation/fund">Donate</a> | 
<a href="//www.loc.gov/about/oig/">Inspector General</a> | 
<a href="//www.loc.gov/homepage/legal.html" accesskey="9">Legal</a> | 
<a href="//www.loc.gov/access/" accesskey="0">Accessibility</a> | 
<a href="//www.loc.gov/global/disclaim.html">External Link Disclaimer</a> |  
<a href="http://www.usa.gov/">USA.gov</a> | 
<a href="//www.loc.gov/access/web.html">Speech Enabled</a>&nbsp;<a href="//www.loc.gov/access/web.html"><img src="//www.loc.gov/include/images/speech.gif" alt="Download BrowseAloud Plugin" width="15" height="12" /></a>
</div>
</div>
</div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>if(window['_satellite']){_satellite.pageBottom();}</script>
</body>
</html>
