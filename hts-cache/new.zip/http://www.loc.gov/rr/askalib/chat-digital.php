<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Chat: Digital Reference Section - Ask a Librarian (Library of Congress)</title>
<meta http-equiv="Content-Language" content="en-us" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="library congress ask a librarian online reference virtual reference digital reference question answer reading room service" />
<meta name="description" content="Ask a librarian: An online reference service from the Library of Congress that allows researchers to submit reference questions to Library of Congress reading rooms and receive expert reseach assistance (within 5 business days.)" />
<link rel="stylesheet" media="print" type="text/css" href="/css/loc_print2col_ss.css" />
<style type="text/css">
@import url(/css/loc_standard_ss.css);
@import url(/rr/askalib/css/askalib_ss.css);
</style>
<script src="https://cdn.loc.gov/sites/ask-a-librarian.js"></script>
<script type='text/javascript' src="https://www.loc.gov/rr/askalib/scripts/submitChat.js"></script>

</head>
<body>
<a id="skip" href="#skip_menu">skip navigation</a>
<div id="container">
  	<div id="topnav">
    <ul id="menu">
      <li id="logo_lc"><a title="The Library of Congress" href="//www.loc.gov" accesskey="1"></a></li>
      <li id="global_nav"><a href="//www.loc.gov/rr/askalib/" accesskey="2"><img src="//www.loc.gov/images/ask_librarian.gif" alt="Ask a Librarian" width="101" height="40" /></a><a href="//www.loc.gov/library/libarch-digital.html" accesskey="3"><img src="//www.loc.gov/images/digital_collections.gif" alt="Digital Collections" width="119" height="40" /></a><a href="http://catalog.loc.gov/" accesskey="4"><img src="//www.loc.gov/images/library_catalog.gif" alt="Library Catalogs" width="111" height="40" /></a></li>
      <li id="searchmenu">
        <form action="//www.loc.gov/search" method="get">
          &nbsp;<label for="search" class="lcsearch_label">Search</label>
          <input type='hidden' name='new' value='true'/>
          <input id="search" type="text" name="q" maxlength="250" accesskey="/" title="Search the Library of Congress website" class="locsuggest" />
          <input class="button" id="search_button" name="search_button" type="submit" value="GO" />
        </form>
      </li>
    </ul>
  </div><!-- end id:topnav -->
  <script src="//cdn.loc.gov/suggest/bootstrap-1.1.0.min.js" type="text/javascript"></script>	
  <div id="crumb_nav">
    <div id="crumb"><a href="/">The Library of Congress</a><span>&nbsp;>&nbsp;</span><a href="index.html">Ask a Librarian</a> &gt; Chat: Digital Reference Section</div>
  </div>
  <div id="content">
	    <div id="left_nav">
      <div id="left_nav_top"><a href="/rr/askalib/"><img src="/rr/askalib/images/lc_askalib.gif" alt="Ask a Librarian" width="197" height="50" /></a></div>
      <div id="left_nav_mid">
        <ul id="navigate">
          <li><a href="/rr/askalib/">Ask a Librarian Home</a></li>
          <li><a href="/rr/askalib/faq.html">Frequently Asked Questions</a></li>
          <!-- <li><a href="chat.html">Live Chat</a></li> -->
          <li><a href="/rr/askalib/virtualref.html">Virtual Reference Shelf</a></li>
          <li><a href="/rr/askalib/reference_policy.html">Reference Correspondence Policy</a></li>
        </ul>
        <h2>More Resources</h2>
        <ul id="res_links">
          <li><a href="http://www.copyright.gov/help/">Copyright Help</a></li>
          <li><a href="//www.loc.gov/acq/donatex.html">Donations of Library Materials</a></li>
          <li><a href="//www.loc.gov/duplicationservices/">Duplication Services</a></li>
          <li><a href="//www.loc.gov/rr/program/bib/bibhome.html">Guides and Bibliographies</a></li>
          <li><a href="//www.loc.gov/rr/">Research and Reference Services</a></li>

          <!-- <li><a href="//www.loc.gov/rr/international/portals.html">Portals to the World</a></li> -->

        </ul>
      </div>

<!-- outage messaging 20141230 ... -->
<script>
window.onload = function(){
    var quickAnswers = document.getElementById('quickAnswers');
    var submissionForm = document.getElementById('submissionForm');
    var warningTimeNow = false;
    var outageTimeNow = false;
    var message = '<div style="padding: 5px 0px 5px 10px;"><p style="font: bold; font-size:1.1em; line-height:1.1em; color:#f00;"> The Library\'s Ask a Librarian Service will be offline Saturday, January 3rd, from 12:00 am to 3:00 pm, U.S. EST (5:00 AM to 8:00 PM GMT). We apologize for the inconvenience.</p></div>';

    datetimeMessageStart = new Date('2014-12-30T22:41Z');
    datetimeMessageEnd   = new Date('2015-01-03T20:00Z'); // Date('2015-01-03T20:00Z');
    datetimeOutageStart  = new Date('2015-01-03T05:00Z');   // Date('2015-01-03T05:00Z');
    datetimeOutageEnd    = new Date('2015-01-03T20:00Z'); // Date('2015-01-03T20:00Z');
    datetimeCurrent      = new Date();

    if (datetimeMessageStart.getTime() < datetimeCurrent.getTime()
        && datetimeCurrent.getTime() < datetimeMessageEnd.getTime()) {
        warningTimeNow = true;
    }
    if (datetimeOutageStart.getTime() < datetimeCurrent.getTime()
        && datetimeCurrent.getTime() < datetimeOutageEnd.getTime()) {
        outageTimeNow = true;
    }

    if (warningTimeNow == true ) {
        if (quickAnswers != null) {
            document.getElementById('quickAnswers').innerHTML =
                message + document.getElementById('quickAnswers').innerHTML;
        } else if (submissionForm != null &&  outageTimeNow == true ) {
            document.getElementById('main_body').innerHTML = message ;
        } else {
            document.getElementById('main_body').innerHTML =
                message + document.getElementById('main_body').innerHTML;
        }
    }
};
</script>
<!-- ...outage messaging 20141230 -->

      <!-- closing left_nav div tag -->
    </div>
    <div id="page_head"><span style="width: 100%;"><a name="skip_menu"></a></span>
      <h1 class="oneline">Chat: Digital Reference Section</h1>
    </div>
    <div class="locshare-this" id='instance_id1001'></div>
    <div id="main_menu">
      <div id="main_body">
      
      		
	         
		<p style="font: bold 95%/120% Georgia, Times New Roman, Times, serif; color: #990000;">
		Live Chat is not currently available. 
		<br /><br />
		Please return Monday through Friday 2:00-4:00 PM Eastern Time to Chat with a Librarian.
		<br /> 
		</p>
		<p>
		Or, you can submit your question using our 
		<a href="ask-digital.html">Ask A Librarian web form</a> 
		and you will receive a reply within five business days.
		</p>
			
      		
	                 
      </div>
	  <!-- Do not remove --> <div class="clear"></div> <!-- Do not remove -->	  
    </div>
  </div>
  <div id="footer">
<h3>Stay Connected with the Library <a href="//www.loc.gov/homepage/connect.html">All ways to connect</a> <a class="nounderline" href="//www.loc.gov/homepage/connect.html">&raquo;</a></h3>
<div id="find_us">
<h4>Find us on</h4>
 <a href="http://www.pinterest.com/LibraryCongress/"><img src="//cdn.loc.gov/images/img-foot/pinterest.gif" alt="Pinterest" width="16" height="16" /></a><a href="http://www.facebook.com/libraryofcongress"><img src="//www.loc.gov/include/images/facebook.gif" alt="Facebook" width="16" height="16" /></a><a href="http://twitter.com/librarycongress"><img src="//www.loc.gov/include/images/twitter.gif" alt="Twitter" width="16" height="16" /></a><a href="http://www.youtube.com/libraryofcongress"><img src="//www.loc.gov/include/images/youtube.gif" alt="YouTube" width="16" height="16" /></a><a href="http://www.flickr.com/photos/library_of_congress/"><img src="//www.loc.gov/include/images/flickr.gif" alt="Flickr" width="16" height="16" /></a></div>
<div id="subscribe">
<h4>Subscribe &amp; Comment</h4>
<ul>
<li id="rssandemail"><a href="//www.loc.gov/rss/">RSS &amp; E-Mail</a></li>
<li id="blogs"><a href="http://blogs.loc.gov/">Blogs</a></li>
</ul>
</div>
<div id="download">
<h4>Download &amp; Play</h4>
<ul>
<li id="podcasts"><a href="//www.loc.gov/podcasts/">Podcasts</a></li>
<li id="webcasts"><a href="//www.loc.gov/webcasts/">Webcasts</a></li>
<li id="itunes"><a class="external" href="https://itunes.apple.com/us/institution/library-of-congress/id386017159"><span class="underline">iTunes U</span><span class="external2" title="external link" style="padding-right:8px;">&nbsp;</span></a></li>
</ul>
</div>

<div id="site_links" style="font-size:.95em !important;">
<a href="//www.loc.gov/about/">About</a> | 
<a href="https://www.loc.gov/news">Press</a> | 
<a href="//www.loc.gov/hr/employment/index.php">Jobs</a> | 
<a href="https://www.loc.gov/philanthropy/online-donation/fund">Donate</a> | 
<a href="//www.loc.gov/about/oig/">Inspector General</a> | 
<a href="//www.loc.gov/homepage/legal.html" accesskey="9">Legal</a> | 
<a href="//www.loc.gov/access/" accesskey="0">Accessibility</a> | 
<a href="//www.loc.gov/global/disclaim.html">External Link Disclaimer</a> |  
<a href="http://www.usa.gov/">USA.gov</a> | 
<a href="//www.loc.gov/access/web.html">Speech Enabled</a>&nbsp;<a href="//www.loc.gov/access/web.html"><img src="//www.loc.gov/include/images/speech.gif" alt="Download BrowseAloud Plugin" width="15" height="12" /></a>
</div>
</div>
	
</div>
</body>
</html>
